document.addEventListener('DOMContentLoaded', function () {
  var activateButton = document.getElementById('activateButton');
  activateButton.addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: function () {
          document.body.contentEditable = 'true';
          document.designMode = 'on';
        }
      });
    });
  });
});
