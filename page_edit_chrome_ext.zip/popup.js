document.addEventListener('DOMContentLoaded', function () {
  var enableEditingButton = document.getElementById('enableEditing');
  enableEditingButton.addEventListener('click', function () {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.executeScript(tabs[0].id, {
        code:
          "document.body.contentEditable = 'true'; document.designMode='on';"
      });
    });
  });
});
